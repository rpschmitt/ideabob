FADERGS - Trabalho Avaliado
Disciplina: Computa��o Gr�fica e Modelagem 3D
Professor: Deivith da Cunha
Aluno: Roberto Schmitt
Descri��o: Modelo low-poly do personagem "Pichu" da s�rie "Pokem�n"
Total de v�rtices: 215
Caf� consumido durante o processo: aprox. 0,6 litros
Coment�rio: Dados alguns ajustes, o modelo apresentado tamb�m serve como um Gremlin ou at� o Stitch, amigo da Lilo.