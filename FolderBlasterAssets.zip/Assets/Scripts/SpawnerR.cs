﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnerR : MonoBehaviour
{

    public GameObject enemy;
    float randY;
    Vector2 whereToSpawn;
    public float spawnRate = 2f;
    float nextSpawn = 0f;

    void Update()
    {
        if (Time.time > nextSpawn)
        {
            nextSpawn = Time.time + spawnRate;
            randY = Random.Range (4.5f, 0f);
            whereToSpawn = new Vector2 (transform.position.x, randY);
            Instantiate (enemy, whereToSpawn, Quaternion.identity);
        }
        
    }

}
