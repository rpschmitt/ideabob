﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DroidMovement : MonoBehaviour {

	Rigidbody2D rb;
	public float dirX;
	public float moveSpeed = 20f;

	void Start () {
		rb = GetComponent<Rigidbody2D> ();
	}

	void Update () {
		dirX = Input.acceleration.x * moveSpeed;
		transform.position = new Vector2 (Mathf.Clamp (transform.position.x, -9f, 9f), transform.position.y);
	}

	void FixedUpdate()
	{
		rb.velocity = new Vector2 (dirX, 0f);
	}

}