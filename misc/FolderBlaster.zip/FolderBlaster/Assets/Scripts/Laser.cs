﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Laser : MonoBehaviour
{
	private LineRenderer lineRenderer;
	public Transform LaserHit;

	void Start ()
	{
		lineRenderer = GetComponent<LineRenderer>();
		lineRenderer.enabled = false;
		lineRenderer.useWorldSpace = true;
	}

    private Touch touch;

	void Update ()
	{
		RaycastHit2D hit = Physics2D.Raycast(transform.position, transform.up);
		Debug.DrawLine(transform.position, hit.point);
		LaserHit.position = hit.point;
		lineRenderer.SetPosition(0, transform.position);
		lineRenderer.SetPosition(1, LaserHit.position);
		if(Input.touchCount > 0)
		{
			lineRenderer.enabled = true;
            Vector2 touchPos = Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position);
            lineRenderer.SetPosition(1, touchPos);
		}
		else
		{
			lineRenderer.enabled = false;
		}
	}
}
