﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAI : MonoBehaviour {

    private Rigidbody2D rb;
    public SpriteRenderer spriteRen;
    public float speed = 3f;
    public float health = 2f;

	void Start () {
        rb = GetComponent<Rigidbody2D>();
        spriteRen = GetComponent<SpriteRenderer>();
        speed = speed + Random.Range(1f, 4f);
        if (this.transform.position.x >= 0f)
        {
            speed = speed * (-1);
        }
	}
	
	void Update () {
        rb.velocity = new Vector2(speed, 0);
        if (health <= 0)
        {
            Destroy(gameObject);
        }
	}

    void OnBecameInvisible () {
        Destroy(gameObject);
    }

}
