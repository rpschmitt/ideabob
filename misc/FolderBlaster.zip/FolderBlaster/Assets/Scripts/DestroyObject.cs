﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyObject : MonoBehaviour {

    public AudioSource destroyFX;

    void Start ()
    {
        destroyFX = GetComponent<AudioSource>();
    }

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.gameObject.tag == "Enemy")
        {
        destroyFX.Play ();
	    Destroy(col.gameObject);
//		GameObject Enemy = GameObject.FindWithTag("Enemy");
//      EnemyAI enemyAI = Enemy.GetComponent<EnemyAI>();
//      enemyAI.spriteRen.color = Color.red;
        }
	}
}
