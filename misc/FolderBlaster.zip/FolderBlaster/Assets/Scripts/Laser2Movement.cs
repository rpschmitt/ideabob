﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Laser2Movement : MonoBehaviour {

	Rigidbody2D rb;
	public float directionX;
	public float moveSpeed = 20f;

	void Start () {
		rb = GetComponent<Rigidbody2D> ();
	}

	void Update () {
		directionX = Input.acceleration.x * moveSpeed;
		transform.position = new Vector2 (Mathf.Clamp (transform.position.x, -8.07f, 8.33f), transform.position.y);
	}

	void FixedUpdate()
	{
		rb.velocity = new Vector2 (directionX, 0f);
	}

}
