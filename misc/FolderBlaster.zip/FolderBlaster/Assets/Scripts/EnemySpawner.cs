﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{

    public GameObject enemy;
    float leftRight;
    float randomX;
    float randomY;
    Vector2 spawnPosition;
    public float spawnRate = 0.8f;
    public float spawnTotal = 0;
    float nextSpawn = 0f;

    void Update()
    {
        if (Time.time > nextSpawn)
        {
            nextSpawn = Time.time + spawnRate + Random.Range(0.2f, 0.5f);
            leftRight = Random.value;
            if (leftRight < 0.5f){
                randomX = -10f; // Left
            }
            if (leftRight >= 0.5f){
                randomX = 10f; // Right
            }
            randomY = Random.Range (4.5f, -0.5f);
            spawnPosition = new Vector2 (randomX, randomY);
            Instantiate (enemy, spawnPosition, Quaternion.identity);
            spawnTotal = spawnTotal + 1;
        }

        if (spawnTotal >= 100)
        {
            // To do: after killing 100 enemies, spawn Boss.
        }        
    }

}
